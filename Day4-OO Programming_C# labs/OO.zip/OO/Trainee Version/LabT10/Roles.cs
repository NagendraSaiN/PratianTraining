﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LabT10
{
    class Roles
    {
    
        public static readonly int DEVELOPER = 1;
        public static readonly int TEST_ENGINEER = 2;
        public static readonly int SR_DEVELOPER = 3;
        public static readonly int DESIGNER = 4;
    }
}
