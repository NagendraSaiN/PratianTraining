﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab7
{
    class ResultFinder
    {
     
        public int Marks1 { get; set; }
	public int Marks2 { get; set; }
	public int Marks3 { get; set; }
        
   
        public void DisplayMarks()
        {
	    
        }

 
        public int GetTotal()
        {
            
        }

   
        public double GetAverage()
        {
            
        }

 
        public string GetResult()
        {
            
        }
    }
}
