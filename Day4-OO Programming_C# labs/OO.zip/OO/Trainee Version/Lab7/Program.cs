﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab7
{
    class Program
    {
        static void Main(string[] args)
        {
          
            int Marks1 = int.Parse(args[0]);
            int Marks2 = int.Parse(args[1]);
            int Marks3 = int.Parse(args[2]);

            ResultFinder Finder = new ResultFinder();
            Finder.Marks1 = Marks1;
            Finder.Marks2 = Marks2;
            Finder.Marks3 = Marks3;

          
            Console.WriteLine("Marks entered------------- ");
            Console.WriteLine("Marks 1 : " + Finder.Marks1);
            Console.WriteLine("Marks 2 : " + Finder.Marks2);
            Console.WriteLine("Marks 3 : " + Finder.Marks3);
            Console.WriteLine("Total : " + Finder.GetTotal());
            Console.WriteLine("Average : " + Finder.GetAverage());
            Console.WriteLine("Result : " + Finder.GetResult());

            Console.ReadLine();
        }
    }
}
