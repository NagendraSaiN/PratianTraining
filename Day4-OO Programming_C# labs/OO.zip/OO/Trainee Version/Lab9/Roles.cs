﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab9
{
    class Roles
    {
       
        public static readonly int DEVELOPER = 1;
        
        
    }
}
